<?php
//criação da classe de conexão pública
class Conexao {
    private $host = "localhost"; // não declara o tipo (onde o nosso usuário vai entrar)
    private $usuario = "root"; // Atribui r[t para usuario
    private $senha = "";   // Sem senha definida
    private $banco = "exemplo_aula_pw"; // Banco do Sql
    private $conexao; // Variavel ainda indefinida

    
    public function __construct() { // metodo para construir
        //passagem dos parametros para o mysqli
        $this->conexao = new mysqli($this->host, $this->usuario, $this->senha, $this->banco);
        //Acessando plo this (encapsulamento) criação da instância, mysqli(classe com crud) e parametros
        if ($this->conexao->connect_error) {
            die("Falha na conexão: " . $this->conexao->connect_error); // se não conseguir cumprir o primeira método retorna falha
        }
    }
     /
    public function getConexao() { // Função retorna a conexão com o banco de dados
        return $this->conexao;
    }
}

// nesta classe definimos algumas propriedades como host, usuário, senha e nome do banco do banco.

?>